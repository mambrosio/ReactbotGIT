module.exports ={
googleProjectID: 'reactpageagent-yaqrpt',
dialogFlowSessionID: 'reac-bot-session',
dialogFlowSessionLanguajeCode: 'en-US'
}